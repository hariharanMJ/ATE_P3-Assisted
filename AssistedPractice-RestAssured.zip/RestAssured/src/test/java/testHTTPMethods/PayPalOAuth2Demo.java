package testHTTPMethods;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
public class PayPalOAuth2Demo {

	String clientid = "AbJwT1ed32uYMecir3nda6uF4d6KYjOV3j7YJKUakK8dAHfOISl8JI31JoHu847BGziruA-RE8GmlEkf";
	
	String clientsecret= "EOvCmSdkCYU2vdqmNZPksh908MnmO5cSaUvj5Zf-eru3wn6E7R2aYyo4S5NlF27oJQk95vJARdnYgl7S";

	String accesstoken;
	
	@Test
	public void getBearerToken()
	{
		Response res = RestAssured.given()
		.baseUri("https://api-m.sandbox.paypal.com")
		.basePath("/v1/oauth2/token")
		.auth().preemptive().basic(clientid, clientsecret)
		.param("grant_type", "client_credentials")
		.when().post();
		
		// res.prettyPrint();
		
		accesstoken =	res.getBody().path("access_token");
		
		System.out.println(accesstoken);
	}
	
	
	@Test
	public void paypalApitest()
	{
		RestAssured.given()
		.baseUri("https://api-m.sandbox.paypal.com")
		.basePath("/v2/invoicing/invoices")
		.queryParam("page", "3")
		.queryParam("page_size", "4")
		.queryParam("total_required", true)
		.auth().oauth2(accesstoken)
		.when().get()
		.then().statusCode(200).log().all();
	}


}
