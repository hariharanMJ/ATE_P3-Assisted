package testHTTPMethods;

import java.util.HashMap;

import io.restassured.RestAssured;

public class POSTDemoContentMap {

	public static void main(String[] args) {
		// create a hash map to store key and value
		// these values we are going to send with our POST request
	
		
		HashMap<String,String> map = new HashMap<String, String>();
		
		map.put("name", "Sally");
		map.put("job", "tester");
		
		RestAssured.given()
		.baseUri("https://reqres.in/")   // URL
		.basePath("/api/users")  // request path
		.contentType("application/json") // what type of content body we are sending - JSON
		.body(map)
		.when().post()
		.then().statusCode(201).log().all();
		

	}

}
