package testHTTPMethods;
import static org.hamcrest.Matchers.*;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;
import io.restassured.RestAssured;;
public class HamcrestDemo {
	// contains() method. it will check response body of the request
		// The response body array length should be same as container method length of values.
	//contains desired items or not. Also it will check in a strict order
		
		String PMkey= "PMAK-65c9a3a526ade100014fd223-290fe004c43bf816fa9820d3210b519dda";
		
		@Test
		public void container_method_demo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces.name", Matchers.contains("My Workspace","ATE-P3","Workspace-12feb","Workspace-new","AssistedPractice"));

		}
		//@Test  // validate if the response body is empty or not
		public void empyMehtoddemo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces.name", empty());
			// assertion will occur as response body is not empty
			// if response body is empty , our test will be success
		}
		
		
		
		//@Test  // validate if the response body is empty or not
		public void IsNotEmpyMehtoddemo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces.name", is(not(empty())));
			// assertion will occur as response body is not empty
			// if response body is empty , our test will be success
		}
		// hasSize() : check if the given number of collection value is as expected or not
		// if Iam expecting numbe rof workspaces to be 15, hasSize will check the repsonse body for number of workspace in the repsonse
		
		
		//@Test  // validate if the response body is empty or not
		public void hasSizeMehtoddemo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces.name", hasSize(6))
			.body("workspaces.name", Matchers.hasItems("Workspace-12feb"));
			
		}
		
		
		//@Test
		public void everyItemMehtoddemo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces.name", everyItem(startsWith("workspace")));
			
		}
		
		//@Test
		public void hasKeyMehtoddemo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces[0]", hasKey("id"));
		
		}
		
		
		//@Test
		public void hasValueMehtoddemo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces[0]", hasValue("personal"));
		
		}
		
		// assert if a collection has a entry ==> key and value
		
		//@Test
		public void hasEntryMehtoddemo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces[0]", hasEntry("id","82112ad0-4602-4df3-81d9-a1e01dc87c70"));
		
		}
		
		
		// check in the response body we have an entry starting with a String or contains a String
		
		
		@Test
		public void AnyOfMehtoddemo()
		{
			RestAssured.given()
			.baseUri("https://api.postman.com")
			.basePath("/workspaces")
			.header("x-api-key",PMkey)
			.when().get()
			.then()
			.statusCode(200)
			.body("workspaces[0].name",anyOf(startsWith("My"),containsString("Workspace")));
		// we have used 2 assertion methods
			
		}


		
}
