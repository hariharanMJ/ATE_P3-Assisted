package testHTTPMethods;
import org.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class ExtractInt {

	public static void main(String[] args) {

		JSONObject body = new JSONObject();
		
		body.put("name", "megha");
		body.put("salary", "12004");
		body.put("age", "36");
		
	// Extract a integer from the response Body	
		
		int responseId =	RestAssured.given()
		.baseUri("https://dummy.restapiexample.com")
		.basePath("/api/v1")
		.contentType(ContentType.JSON)
		.body(body)
		.when().post("/create")
		.then()
		.statusCode(200)
		.extract().path("data.id");
		
		System.out.println("The is of the response is :" + responseId);
		


	}

}
